#define TESTING 1
#include <portable/strndup.c>
