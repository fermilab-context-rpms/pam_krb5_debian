#define TESTING 1
#include <portable/mkstemp.c>
